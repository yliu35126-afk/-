// 配置文件
module.exports = {
    // 服务器配置
    server: {
        port: 3001,
        apiBaseUrl: 'https://yiqilishi.com.cn/index.php/api'
    },
    
    // 数据库配置
    database: {
        host: 'localhost',
        user: 'tv923',
        password: '8CaYtyeTrX3At4Wx',
        database: 'tv923',
        charset: 'utf8mb4',
        timezone: '+08:00'
    },
    
    // CORS配置
    cors: {
        origins: [
            'https://yiqilishi.com.cn', 
            'https://yiqilishi.com.cn', 
            'http://localhost:3000'
        ]
    }
};