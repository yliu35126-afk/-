const { devices, users, deviceRooms, setDeviceBusy, releaseDevice, isDeviceBusy, getDeviceStatus } = require('./deviceManager');
const { findAvailableOrder, updateOrderStatus } = require('./orderService');
const { getProfitConfigById } = require('./profitService');
const { updateOrderPrize, updateDeviceOnlineStatus, verifyDevice } = require('./database');

// Socket事件处理模块

function handleSocketEvents(io, socket) {
    
    // 设备注册
    socket.on('device_register', async (data) => {
        const { device_id, device_name, device_type } = data;
        
        if (!device_id) {
            socket.emit('error', { message: '设备ID不能为空' });
            return;
        }
        
        console.log(`设备注册请求: ${device_id} (${device_name})`);
        
        // 验证设备是否存在
        const isValidDevice = await verifyDevice(device_id);
        if (!isValidDevice) {
            socket.emit('device_register_response', {
                success: false,
                message: '设备未注册或不存在'
            });
            return;
        }
        
        // 保存设备信息
        devices.set(socket.id, {
            device_id,
            device_name,
            device_type,
            socket_id: socket.id,
            registered_at: new Date(),
            last_heartbeat: new Date()
        });
        
        // 创建或加入设备房间
        const roomName = `device_${device_id}`;
        socket.join(roomName);
        deviceRooms.set(device_id, roomName);
        
        // 更新数据库中的设备在线状态
        await updateDeviceOnlineStatus(device_id, true, new Date());
        
        // 确认注册成功
        socket.emit('device_registered', {
            success: true,
            device_id,
            message: '设备注册成功',
            room: roomName
        });
        
        console.log(`✅ 设备 ${device_id} 注册成功，房间: ${roomName}`);
    });
    
    // 用户加入设备
    socket.on('user_join', async (data) => {
        const { device_id, user_id, user_name, openid, game_type = 'lottery' } = data;
        
        console.log(`用户加入: ${user_id} -> 设备 ${device_id}`);
        
        // 加入设备房间
        const roomName = `device_${device_id}`;
        socket.join(roomName);
        
        // 保存用户信息
        users.set(socket.id, {
            device_id,
            user_id,
            user_name,
            openid,
            game_type,
            socket_id: socket.id,
            joined_at: new Date()
        });
        
        // 确认加入成功
        socket.emit('joined_device', {
            success: true,
            device_id,
            user_id,
            message: `已加入设备 ${device_id}`,
            room: roomName
        });
        
        // 通知设备有新用户加入
        socket.to(roomName).emit('user_joined', {
            user_id,
            user_name,
            device_id,
            timestamp: new Date().toISOString()
        });
        
        console.log(`✅ 用户 ${user_id} 加入设备 ${device_id} 成功`);
    });
    
    // 用户发起抽奖
    socket.on('start_lottery', async (data) => {
        console.log('收到抽奖请求:', data);
        
        const { device_id, user_id, openid, game_type = 'lottery', config_id } = data;
        
        // 如果没有指定设备ID，返回错误
        if (!device_id) {
            socket.emit('error', { message: '缺少设备ID' });
            return;
        }
        
        if (!openid) {
            socket.emit('error', { message: '缺少openid' });
            return;
        }
        
        // 检查设备是否正在游戏中（先到先得）
        if (isDeviceBusy(device_id)) {
            const currentStatus = getDeviceStatus(device_id);
            const busyDuration = Math.round((Date.now() - currentStatus.startTime) / 1000);
            
            socket.emit('error', { 
                message: '设备正在游戏中，请稍后再试',
                code: 'DEVICE_BUSY',
                current_user: currentStatus.currentUser.user_id,
                busy_duration: busyDuration
            });
            console.log(`⚠️ 设备${device_id}正忙，拒绝用户${user_id}的抽奖请求，当前用户：${currentStatus.currentUser.user_id}，已持续${busyDuration}秒`);
            return;
        }
        
        // 验证config_id（如果提供）
        if (config_id) {
            const configResult = await getProfitConfigById(device_id, config_id);
            if (!configResult) {
                socket.emit('error', { 
                    message: `分润配置ID=${config_id}无效或不属于该设备`,
                    code: 'INVALID_CONFIG_ID'
                });
                return;
            }
            console.log(`✅ 验证分润配置成功: ID=${config_id}, 名称=${configResult.config_name}, 金额=${configResult.lottery_amount}元`);
        }
        
        // 自动将用户加入到设备房间（简化流程）
        const roomName = `device_${device_id}`;
        socket.join(roomName);
        
        console.log(`用户 ${user_id} (openid: ${openid}) 自动加入设备 ${device_id}${config_id ? ', config_id=' + config_id : ''}`);
        
        try {
            // 查找已支付的订单
            const existingOrder = await findAvailableOrder(openid);
            
            // 如果没有找到已支付订单，返回错误
            if (!existingOrder) {
                socket.emit('error', { 
                    message: '未找到可用的已支付订单，请先支付再开始游戏',
                    code: 'NO_PAID_ORDER'
                });
                console.warn(`⚠️ 用户${user_id}未找到可用订单，openid=${openid}`);
                return;
            }
            
            // 使用已支付订单
            const saveResult = { success: true, order_id: existingOrder.id };
            const orderAmount = parseFloat(existingOrder.order_amount);
            const orderConfigId = existingOrder.config_id || config_id; // 优先使用订单中的config_id
            console.log(`🎮 使用已支付订单: 订单ID=${existingOrder.id}, 金额=${orderAmount}元, 配置ID=${orderConfigId}`);
            
            // 创建用户信息
            const userInfo = {
                device_id: device_id,
                user_id: user_id || 'user_' + Date.now(),
                openid: openid,
                game_type: game_type,
                config_id: orderConfigId,
                order_id: saveResult.order_id,
                order_amount: orderAmount,
                socket_id: socket.id,
                joined_at: new Date()
            };
            
            // 设置设备为忙碌状态（先到先得，抢占设备）
            setDeviceBusy(device_id, userInfo);
            
            // 保存用户信息
            users.set(socket.id, userInfo);
            
            const { lottery_type = 1, user_name, user_phone } = data;
            
            // 获取设备房间
            let targetRoomName = deviceRooms.get(device_id);
            
            // 如果设备不在线，仍然发送指令（可能是离线处理）
            if (!targetRoomName) {
                targetRoomName = roomName; // 使用当前房间名
                console.log(`设备 ${device_id} 离线，尝试发送指令到房间 ${targetRoomName}`);
            }

            const lotteryData = {
                user_id: userInfo.user_id,
                device_id: device_id,
                lottery_type,
                user_name,
                user_phone,
                order_id: saveResult.order_id,
                order_amount: orderAmount,
                config_id: orderConfigId || null,
                timestamp: new Date().toISOString()
            };

            console.log(`用户发起抽奖: ${device_id}`, lotteryData);

            // 发送抽奖指令给设备
            socket.to(targetRoomName).emit('lottery_command', lotteryData);
            
            // 同时发送给所有连接到该设备的客户端
            io.to(roomName).emit('game_started', {
                device_id: device_id,
                user_id: userInfo.user_id,
                order_id: saveResult.order_id,
                order_amount: orderAmount,
                message: '抽奖已开始，设备已被占用，等待抽奖结果'
            });

            // 确认用户抽奖请求已发送
            socket.emit('lottery_sent', {
                success: true,
                message: '抽奖指令已发送到设备，设备已被占用，等待抽奖结果',
                order_id: saveResult.order_id,
                order_amount: orderAmount,
                data: lotteryData
            });
            
        } catch (error) {
            console.error('❌ 处理抽奖请求失败:', error);
            socket.emit('error', { message: '订单处理失败，请稍后再试' });
        }
    });
    
    // 设备返回抽奖结果
    socket.on('lottery_result', async (data) => {
        const device = devices.get(socket.id);
        if (!device) {
            socket.emit('error', { message: '设备未注册' });
            return;
        }

        const { user_id, result, prize_info, lottery_record_id } = data;
        const roomName = deviceRooms.get(device.device_id);

        console.log(`设备返回抽奖结果: ${device.device_id}`, data);

        try {
            // 查找对应的用户信息，获取订单ID、订单金额和config_id
            let targetOrderId = null;
            let orderAmount = null;
            let userInfo = null;
            let configId = null;
            let userSocketId = null;
            
            // 从设备状态中获取当前用户信息
            const deviceStatus = getDeviceStatus(device.device_id);
            if (deviceStatus && deviceStatus.currentUser.user_id === user_id) {
                userInfo = deviceStatus.currentUser;
                targetOrderId = userInfo.order_id;
                orderAmount = userInfo.order_amount;
                configId = userInfo.config_id;
                userSocketId = userInfo.socket_id;
            } else {
                // 如果设备状态中没有找到，回退到遍历用户列表
                for (const [socketId, info] of users.entries()) {
                    if (info.user_id === user_id && info.device_id === device.device_id) {
                        targetOrderId = info.order_id;
                        orderAmount = info.order_amount;
                        userInfo = info;
                        configId = info.config_id;
                        userSocketId = socketId;
                        break;
                    }
                }
            }

            console.log(`🎯 找到用户信息: 用户=${user_id}, 订单=${targetOrderId}, 金额=${orderAmount}, 配置=${configId}`);

            // 检查订单是否已经处理过
            if (targetOrderId) {
                const orderStatus = await require('./orderService').getOrderStatus(targetOrderId);
                
                if (orderStatus && orderStatus.prize_id > 0) {
                    console.warn(`⚠️ 订单${targetOrderId}已经处理过，跳过重复处理`);
                    return;
                }
            }

            // 如果中奖且找到了订单ID，更新订单奖品信息
            if (result === 'win' && prize_info && targetOrderId) {
                const updateResult = await updateOrderPrize(targetOrderId, prize_info);
                if (updateResult.success) {
                    data.order_id = targetOrderId;
                    console.log(`🎁 订单奖品更新成功: 用户=${user_id}, 奖品=${prize_info.name}, 订单ID=${targetOrderId}`);
                }
            } else if (targetOrderId) {
                // 未中奖也要更新订单状态为已完成
                await updateOrderStatus(targetOrderId, 3, 0);
                console.log(`📝 订单状态更新为已完成: 订单ID=${targetOrderId} (未中奖)`);
                data.order_id = targetOrderId;
            }

            // 清理用户状态和释放设备
            if (userSocketId && users.has(userSocketId)) {
                const userData = users.get(userSocketId);
                users.set(userSocketId, userData);
                console.log(`🏁 用户抽奖状态已清理: ${user_id}`);
            }
            
            // 释放设备状态（设备独占模式）
            releaseDevice(device.device_id);
            console.log(`🔓 设备${device.device_id}已释放，可接受新的抽奖请求`);

            // 发送结果给指定用户
            if (user_id) {
                io.to(user_id).emit('lottery_result', {
                    success: true,
                    result,
                    prize_info,
                    lottery_record_id,
                    device_id: device.device_id,
                    order_id: data.order_id,
                    timestamp: new Date().toISOString()
                });
            }

            // 广播给房间内所有用户（用于大屏显示）
            socket.to(roomName).emit('lottery_broadcast', {
                result,
                prize_info,
                device_id: device.device_id,
                timestamp: new Date().toISOString()
            });
            
        } catch (error) {
            console.error('❌ 处理抽奖结果失败:', error);
        }
    });

    // 心跳检测
    socket.on('heartbeat', async () => {
        const device = devices.get(socket.id);
        if (device) {
            device.last_heartbeat = new Date();
            
            // 更新数据库中的心跳时间
            await updateDeviceOnlineStatus(device.device_id, true, device.last_heartbeat);
        }
        socket.emit('heartbeat_response', { timestamp: new Date().toISOString() });
    });

    // 获取设备状态
    socket.on('get_device_status', () => {
        const device = devices.get(socket.id);
        if (device) {
            const roomName = deviceRooms.get(device.device_id);
            const roomUsers = Array.from(users.values()).filter(u => u.device_id === device.device_id);
            
            socket.emit('device_status', {
                device: device,
                room: roomName,
                users: roomUsers,
                timestamp: new Date().toISOString()
            });
        } else {
            socket.emit('error', { message: '设备未注册' });
        }
    });

    // 连接断开处理
    socket.on('disconnect', async () => {
        const device = devices.get(socket.id);
        const user = users.get(socket.id);
        
        if (device) {
            console.log(`设备断开连接: ${device.device_id}`);
            
            // 更新数据库中的设备离线状态
            await updateDeviceOnlineStatus(device.device_id, false);
            
            devices.delete(socket.id);
            deviceRooms.delete(device.device_id);
            
            // 如果设备断开，释放其状态
            releaseDevice(device.device_id);
        }
        
        if (user) {
            console.log(`用户断开连接: ${user.user_id}`);
            users.delete(socket.id);
            
            // 如果用户断开且设备正在被其占用，释放设备
            if (user.device_id) {
                const deviceStatus = getDeviceStatus(user.device_id);
                if (deviceStatus && deviceStatus.currentUser.socket_id === socket.id) {
                    releaseDevice(user.device_id);
                    console.log(`🔓 用户断开连接，释放设备${user.device_id}`);
                }
            }
        }
    });
}

module.exports = { handleSocketEvents };