const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const config = require('./config');
const { handleSocketEvents } = require('./socketHandlers');
const { devices, startHeartbeatCheck } = require('./deviceManager');
const { updateDeviceOnlineStatus } = require('./database');

const app = express();
const server = http.createServer(app);

// 配置CORS
app.use(cors({
    origin: config.cors.origins,
    credentials: true
}));

const io = socketIo(server, {
    cors: {
        origin: config.cors.origins,
        methods: ['GET', 'POST'],
        credentials: true
    }
});

app.use(express.json());

// 基础路由
app.get('/', (req, res) => {
    res.json({ 
        message: 'TV Game WebSocket Server',
        status: 'running',
        timestamp: new Date().toISOString()
    });
});

// 健康检查端点
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    });
});

// 获取在线设备信息 - 给后端管理系统使用
app.get('/devices', (req, res) => {
    try {
        const onlineDevices = [];
        
        // 将devices Map转换为数组格式
        for (const [socketId, deviceInfo] of devices.entries()) {
            onlineDevices.push({
                device_id: deviceInfo.device_id,
                connected_at: deviceInfo.registered_at.toISOString(),
                last_heartbeat: deviceInfo.last_heartbeat.toISOString(),
                device_type: deviceInfo.device_type || 'unknown',
                socket_id: socketId,
                device_name: deviceInfo.device_name || ''
            });
        }
        
        res.json({
            success: true,
            count: onlineDevices.length,
            devices: onlineDevices,
            timestamp: new Date().toISOString()
        });
        
        console.log(`📊 返回在线设备信息: ${onlineDevices.length}台设备`);
    } catch (error) {
        console.error('❌ 获取设备信息失败:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            devices: []
        });
    }
});

// Socket连接处理
io.on('connection', (socket) => {
    console.log(`🔗 新连接: ${socket.id} (来自 ${socket.handshake.address})`);
    
    // 处理所有Socket事件
    handleSocketEvents(io, socket);
});

// 启动服务器
const PORT = config.server.port;
server.listen(PORT, () => {
    console.log(`🚀 WebSocket服务器启动成功！`);
    console.log(`📡 端口: ${PORT}`);
    console.log(`🌐 CORS允许来源: ${config.cors.origins.join(', ')}`);
    console.log(`📊 服务器状态: http://localhost:${PORT}/health`);
    console.log(`⏰ 启动时间: ${new Date().toISOString()}`);
    
    // 启动心跳检查服务（仅监控超时，不主动发送）
    startHeartbeatCheck(io, updateDeviceOnlineStatus);
    console.log(`💓 心跳监控服务已启动 (客户端主动发送模式)`);
});

// 移除旧的定期清理代码，已在 deviceManager 中实现

// 优雅关闭
process.on('SIGTERM', () => {
    console.log('🛑 收到SIGTERM信号，准备关闭服务器...');
    server.close(() => {
        console.log('✅ 服务器已关闭');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('🛑 收到SIGINT信号，准备关闭服务器...');
    server.close(() => {
        console.log('✅ 服务器已关闭');
        process.exit(0);
    });
});

module.exports = { app, server, io };