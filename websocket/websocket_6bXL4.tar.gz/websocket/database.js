const mysql = require('mysql2/promise');
const config = require('./config');

// 创建数据库连接池
const pool = mysql.createPool(config.database);

// 数据库操作函数
async function saveOrderToDB(orderData) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        
        const [result] = await connection.execute(
            `INSERT INTO fa_order (
                openid, user_id, device_id, order_amount, lottery_amount, 
                pay_status, order_status, createtime, updatetime, config_id
            ) VALUES (?, ?, ?, ?, ?, 'unpaid', 0, ?, ?, ?)`,
            [
                orderData.openid,
                orderData.user_id || 'anonymous',
                orderData.device_id,
                orderData.order_amount,
                orderData.lottery_amount || orderData.order_amount,
                Math.floor(Date.now() / 1000),
                Math.floor(Date.now() / 1000),
                orderData.config_id || 0
            ]
        );
        
        await connection.commit();
        console.log(`✅ 订单保存成功: ID=${result.insertId}`);
        
        return { success: true, order_id: result.insertId };
    } catch (error) {
        await connection.rollback();
        console.error('❌ 保存订单到数据库失败:', error);
        return { success: false, error: error.message };
    } finally {
        connection.release();
    }
}

async function updateOrderPrize(orderId, prizeInfo) {
    const connection = await pool.getConnection();
    try {
        await connection.execute(
            `UPDATE fa_order SET 
                prize_id = ?, prize_name = ?, order_status = 3, updatetime = ?
             WHERE id = ?`,
            [
                prizeInfo.id,
                prizeInfo.name,
                Math.floor(Date.now() / 1000),
                orderId
            ]
        );
        console.log(`🎁 订单奖品更新成功: 订单=${orderId}, 奖品=${prizeInfo.name}`);
        return { success: true };
    } catch (error) {
        console.error('❌ 更新订单奖品失败:', error);
        return { success: false, error: error.message };
    } finally {
        connection.release();
    }
}

async function getLotteryAmount() {
    try {
        const connection = await pool.getConnection();
        const [rows] = await connection.execute(
            'SELECT option_value FROM fa_config WHERE name = "lottery_amount"'
        );
        connection.release();
        
        if (rows.length > 0) {
            const amount = parseFloat(rows[0].option_value);
            return isNaN(amount) ? 10 : amount;
        }
        return 10; // 默认金额
    } catch (error) {
        console.error('❌ 获取抽奖金额失败:', error);
        return 10; // 返回默认值
    }
}

// 更新设备在线状态
async function updateDeviceOnlineStatus(deviceId, isOnline, lastHeartbeat = null) {
    const connection = await pool.getConnection();
    try {
        const currentTime = new Date().toISOString();
        const heartbeatTime = lastHeartbeat ? lastHeartbeat.toISOString() : currentTime;
        
        if (isOnline) {
            // 设备上线，更新心跳时间和在线时间
            await connection.execute(
                `UPDATE fa_device SET 
                    last_heartbeat_time = ?, 
                    last_online_time = ?, 
                    updatetime = ? 
                 WHERE device_id = ?`,
                [heartbeatTime, currentTime, Math.floor(Date.now() / 1000), deviceId]
            );
        } else {
            // 设备离线，只更新updatetime
            await connection.execute(
                `UPDATE fa_device SET 
                    updatetime = ? 
                 WHERE device_id = ?`,
                [Math.floor(Date.now() / 1000), deviceId]
            );
        }
        
        console.log(`📱 设备${deviceId}状态更新: ${isOnline ? '在线' : '离线'}`);
        return { success: true };
    } catch (error) {
        console.error('❌ 更新设备在线状态失败:', error);
        return { success: false, error: error.message };
    } finally {
        connection.release();
    }
}

// 验证设备是否存在
async function verifyDevice(deviceId) {
    const connection = await pool.getConnection();
    try {
        const [rows] = await connection.execute(
            'SELECT id FROM fa_device WHERE device_id = ?',
            [deviceId]
        );
        
        const isValid = rows.length > 0;
        console.log(`🔍 设备验证: ${deviceId} - ${isValid ? '有效' : '无效'}`);
        return isValid;
    } catch (error) {
        console.error(`❌ 验证设备${deviceId}失败:`, error);
        return false;
    } finally {
        connection.release();
    }
}

module.exports = {
    pool,
    saveOrderToDB,
    updateOrderPrize,
    getLotteryAmount,
    updateDeviceOnlineStatus,
    verifyDevice
};