const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const axios = require('axios');
const mysql = require('mysql2/promise');

const app = express();
const server = http.createServer(app);

// MySQL数据库配置
const dbConfig = {
    host: 'localhost',
    user: '12312321313',
    password: '4hhXZSB7d8GeC7m8',
    database: '12312321313',
    charset: 'utf8mb4',
    timezone: '+08:00'
};

// 创建数据库连接池
const pool = mysql.createPool(dbConfig);

// 配置CORS
app.use(cors({
    origin: ['https://tvgame.jiandunyun.com', 'https://tvdemo.jiandunyun.com', 'http://localhost:3000'],
    credentials: true
}));

const io = socketIo(server, {
    cors: {
        origin: ['https://tvgame.jiandunyun.com', 'https://tvdemo.jiandunyun.com', 'http://localhost:3000'],
        methods: ['GET', 'POST'],
        credentials: true
    }
});

app.use(express.json());

// 存储设备和用户连接信息
const devices = new Map(); // 设备连接信息
const users = new Map();   // 用户连接信息
const deviceRooms = new Map(); // 设备房间管理

// 配置
const config = {
    port: 3001,
    apiBaseUrl: 'https://tvdemo.jiandunyun.com/index.php/api'
};

// 数据库操作函数
async function saveOrderToDB(orderData) {
    const connection = await pool.getConnection();
    try {
        const {
            device_id,
            user_id,
            openid = '',
            prize_id = 0,
            prize_name = '',
            order_amount = 20.00, // 固定抽奖金额
            order_status = 1, // 1=已完成
            lottery_record_id
        } = orderData;

        const currentTime = Math.floor(Date.now() / 1000);
        
        const [result] = await connection.execute(
            `INSERT INTO fa_order (device_id, pay_user, openid, order_amount, balance, order_status, prize_id, prize_name, createtime, updatetime) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [device_id, user_id, openid, order_amount, 0.00, order_status, prize_id, prize_name, currentTime, currentTime]
        );
        
        console.log(`📦 订单保存成功: ID=${result.insertId}, 用户=${user_id}, openid=${openid}, 奖品=${prize_name}, 金额=${order_amount}`);
        return { success: true, order_id: result.insertId };
        
    } catch (error) {
        console.error('❌ 保存订单失败:', error);
        return { success: false, error: error.message };
    } finally {
        connection.release();
    }
}

// 更新订单奖品信息
async function updateOrderPrize(orderId, prizeInfo) {
    const connection = await pool.getConnection();
    try {
        const currentTime = Math.floor(Date.now() / 1000);
        
        await connection.execute(
            `UPDATE fa_order SET prize_id = ?, prize_name = ?, order_status = ?, updatetime = ? WHERE id = ?`,
            [prizeInfo.id || 0, prizeInfo.name || '未知奖品', 2, currentTime, orderId]
        );
        
        console.log(`🎁 订单奖品信息更新成功: 订单ID=${orderId}, 奖品=${prizeInfo.name}, 状态已更新为已完成(2)`);
        return { success: true };
        
    } catch (error) {
        console.error('❌ 更新订单奖品失败:', error);
        return { success: false, error: error.message };
    } finally {
        connection.release();
    }
}

// 获取抽奖金额配置
async function getLotteryAmount() {
    const connection = await pool.getConnection();
    try {
        const [rows] = await connection.execute(
            'SELECT value FROM fa_config WHERE name = "lottery_amount"'
        );
        return rows.length > 0 ? parseFloat(rows[0].value) : 20.00;
    } catch (error) {
        console.error('❌ 获取抽奖金额失败:', error);
        return 20.00; // 默认值
    } finally {
        connection.release();
    }
}

// 获取设备绑定的角色用户（根据分润配置动态查询）
async function getDeviceRoleUsers(deviceId, profitConfig) {
    const connection = await pool.getConnection();
    try {
        // 首先获取设备表中的角色字段
        const [deviceRows] = await connection.execute(`
            SELECT d.sheng_daili_id, d.shi_daili_id, d.quxian_daili_id, 
                   d.shebei_goumaizhe_id, d.shebei_pushezhe_id, d.shiti_shangjia_id, d.jiangpin_gongyingshang_ids
            FROM fa_device d WHERE d.device_id = ?
        `, [deviceId]);
        
        if (deviceRows.length === 0) return {};
        
        const device = deviceRows[0];
        
        // 角色ID到设备字段的映射
        const roleFieldMapping = {
            1: null,  // 超级管理组 - 设备表无对应字段
            7: device.sheng_daili_id,     // 省代理
            8: device.shi_daili_id,       // 市代理
            9: device.quxian_daili_id,    // 区县代理
            10: device.shebei_goumaizhe_id,   // 设备购买者
            11: device.shebei_pushezhe_id,    // 设备铺设者
            12: device.shiti_shangjia_id,     // 实体商家
            13: device.jiangpin_gongyingshang_ids, // 奖品供应商（使用复数字段）
            14: null, // 游戏 - 设备表无对应字段
            15: null, // 运营团队 - 设备表无对应字段
            17: null, // 管理员 - 设备表无对应字段
        };
        
        // 根据分润配置中的角色构建返回结果
        const result = {};
        for (const [configKey, config] of Object.entries(profitConfig)) {
            const roleId = config.role_id;
            const deviceUserId = roleFieldMapping[roleId];
            
            // 只有当设备表中有绑定用户且用户ID > 0时，才分润给该角色
            if (deviceUserId && deviceUserId > 0) {
                result[configKey] = deviceUserId;
            }
            // 如果设备没有绑定该角色用户，就不加入result，不进行分润
        }
        
        console.log(`🔍 设备${deviceId}角色用户映射 (共${Object.keys(result).length}个角色):`, result);
        return result;
        
    } catch (error) {
        console.error('❌ 获取设备角色用户失败:', error);
        return {};
    } finally {
        connection.release();
    }
}

// 获取设备指定金额的分润配置（保留兼容性）
async function getProfitConfigByDeviceAndAmount(deviceId, lotteryAmount) {
    const connection = await pool.getConnection();
    try {
        // 1. 获取设备绑定的分润配置IDs
        const [deviceRows] = await connection.execute(
            'SELECT profit_config_ids FROM fa_device WHERE device_id = ?',
            [deviceId]
        );
        
        if (deviceRows.length === 0 || !deviceRows[0].profit_config_ids) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置`);
            return null;
        }
        
        const profitConfigIds = JSON.parse(deviceRows[0].profit_config_ids);
        if (!Array.isArray(profitConfigIds) || profitConfigIds.length === 0) {
            console.warn(`⚠️ 设备${deviceId}分润配置ID数组为空`);
            return null;
        }
        
        // 2. 根据抽奖金额查找对应的分润配置
        // 注意：统一使用decimal格式匹配
        const [configRows] = await connection.execute(
            'SELECT id, config_name, lottery_amount, config_data FROM fa_profit_config WHERE id IN (' + 
            profitConfigIds.map(() => '?').join(',') + ') AND lottery_amount = ? AND status = 1',
            [...profitConfigIds, lotteryAmount]
        );
        
        if (configRows.length === 0) {
            console.warn(`⚠️ 设备${deviceId}未找到金额为${lotteryAmount}的分润配置`);
            return null;
        }
        
        const config = configRows[0];
        const configData = JSON.parse(config.config_data);
        
        // 3. 转换配置数据为分润角色映射
        const profitConfig = {};
        
        // 遍历config_data中的角色配置（排除prizes部分）
        Object.keys(configData).forEach(key => {
            if (key !== 'prizes' && configData[key].role_name && configData[key].amount !== undefined) {
                const roleData = configData[key];
                
                // 直接使用配置项的key作为角色标识，同时保存role_id
                if (parseFloat(roleData.amount) > 0) {
                    const roleAmount = parseFloat(roleData.amount);
                    
                    profitConfig[key] = {
                        role_id: roleData.role_id,
                        role_name: roleData.role_name,
                        amount: roleAmount // 统一使用decimal格式，不除以100
                    };
                }
            }
        });
        
        console.log(`✅ 获取设备${deviceId}金额${lotteryAmount}的分润配置成功:`, profitConfig);
        return {
            config_id: config.id,
            config_name: config.config_name,
            lottery_amount: parseFloat(config.lottery_amount),
            profit_config: profitConfig
        };
        
    } catch (error) {
        console.error(`❌ 获取设备${deviceId}分润配置失败:`, error);
        return null;
    } finally {
        connection.release();
    }
}

// 根据config_id获取设备分润配置（新增）
async function getProfitConfigById(deviceId, configId) {
    const connection = await pool.getConnection();
    try {
        // 1. 获取设备绑定的分润配置IDs
        const [deviceRows] = await connection.execute(
            'SELECT profit_config_ids FROM fa_device WHERE device_id = ?',
            [deviceId]
        );
        
        if (deviceRows.length === 0 || !deviceRows[0].profit_config_ids) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置`);
            return null;
        }
        
        const profitConfigIds = JSON.parse(deviceRows[0].profit_config_ids);
        if (!Array.isArray(profitConfigIds) || profitConfigIds.length === 0) {
            console.warn(`⚠️ 设备${deviceId}分润配置ID数组为空`);
            return null;
        }
        
        console.log(`🔍 设备${deviceId}绑定的分润配置IDs:`, profitConfigIds);
        console.log(`🎯 验证config_id=${configId} (类型: ${typeof configId})`);
        
        // 2. 验证config_id是否在设备绑定的配置列表中
        // 处理字符串和数字的匹配问题
        const configIdNum = parseInt(configId);
        const configIdStr = String(configId);
        const isIncluded = profitConfigIds.includes(configIdNum) || profitConfigIds.includes(configIdStr);
        
        if (!isIncluded) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置ID=${configId}, 绑定的配置: [${profitConfigIds.join(', ')}]`);
            return null;
        }
        
        // 3. 根据config_id直接查找分润配置
        const [configRows] = await connection.execute(
            'SELECT id, config_name, lottery_amount, config_data FROM fa_profit_config WHERE id = ? AND status = 1',
            [configId]
        );
        
        if (configRows.length === 0) {
            console.warn(`⚠️ 分润配置ID=${configId}不存在或已禁用`);
            return null;
        }
        
        const config = configRows[0];
        const configData = JSON.parse(config.config_data);
        
        // 4. 转换配置数据为分润角色映射
        const profitConfig = {};
        
        // 遍历config_data中的角色配置（排除prizes部分）
        Object.keys(configData).forEach(key => {
            if (key !== 'prizes' && configData[key].role_name && configData[key].amount !== undefined) {
                const roleData = configData[key];
                
                // 直接使用配置项的key作为角色标识，同时保存role_id
                if (parseFloat(roleData.amount) > 0) {
                    const roleAmount = parseFloat(roleData.amount);
                    
                    profitConfig[key] = {
                        role_id: roleData.role_id,
                        role_name: roleData.role_name,
                        amount: roleAmount // 统一使用decimal格式，不除以100
                    };
                }
            }
        });
        
        console.log(`✅ 获取设备${deviceId}分润配置ID=${configId}成功:`, profitConfig);
        return {
            config_id: config.id,
            config_name: config.config_name,
            lottery_amount: parseFloat(config.lottery_amount),
            profit_config: profitConfig
        };
        
    } catch (error) {
        console.error(`❌ 获取设备${deviceId}分润配置ID=${configId}失败:`, error);
        return null;
    } finally {
        connection.release();
    }
}

// 创建分润记录（支持config_id和金额两种方式）
async function createProfitRecords(orderId, deviceId, lotteryUserId, orderAmount, prizeInfo = null, configId = null) {
    const connection = await pool.getConnection();
    try {
        // 开启事务
        await connection.beginTransaction();
        
        let configResult = null;
        
        // 根据传入的configId或orderAmount获取分润配置
        if (configId) {
            // 优先使用config_id方式（新方式）
            configResult = await getProfitConfigById(deviceId, configId);
            if (!configResult) {
                console.warn(`⚠️ 设备${deviceId}分润配置ID=${configId}无效，跳过分润处理`);
                await connection.commit();
                return [];
            }
        } else {
            // 兼容原来的金额方式
            configResult = await getProfitConfigByDeviceAndAmount(deviceId, orderAmount);
            if (!configResult) {
                console.warn(`⚠️ 设备${deviceId}金额${orderAmount}无对应分润配置，跳过分润处理`);
                await connection.commit();
                return [];
            }
        }

        const { config_id, config_name, profit_config } = configResult;
        
        // 获取设备绑定的角色用户（传入分润配置）
        const roleUsers = await getDeviceRoleUsers(deviceId, profit_config);
        const currentTime = Math.floor(Date.now() / 1000);
        const profitRecords = [];
        
        console.log(`💰 开始处理分润: 配置ID=${config_id}, 配置名称=${config_name}, 订单金额=${orderAmount}${configId ? ', 使用config_id=' + configId : ''}`);
        if (prizeInfo) {
            console.log(`🎁 中奖奖品信息: ID=${prizeInfo.id}, 名称=${prizeInfo.name}, 供应商=${prizeInfo.supplier || '未知'}`);
        }
        
        // 为每个绑定的角色创建分润记录并更新余额
        for (const [roleKey, config] of Object.entries(profit_config)) {
            const profitUserId = roleUsers[roleKey];
            
            // 特殊处理奖品供应商：只有中奖且奖品有supplier_user_id时才分润给对应供应商
            if (config.role_name === '奖品供应商') {
                // 如果没有中奖，跳过奖品供应商分润
                if (!prizeInfo) {
                    console.log(`⚠️ 跳过奖品供应商分润: 没有中奖`);
                    continue;
                }
                
                // 根据中奖奖品的ID查找对应的supplier_user_id
                const [prizeRows] = await connection.execute(`
                    SELECT supplier_user_id FROM fa_prize WHERE id = ?
                `, [prizeInfo.id]);
                
                if (prizeRows.length === 0 || !prizeRows[0].supplier_user_id || prizeRows[0].supplier_user_id <= 0) {
                    console.log(`⚠️ 跳过奖品供应商分润: 奖品ID=${prizeInfo.id}没有supplier_user_id或为0`);
                    continue;
                }
                
                const prizeSupplierUserId = prizeRows[0].supplier_user_id;
                console.log(`🎯 奖品供应商分润: 奖品="${prizeInfo.name}" (ID=${prizeInfo.id}), 供应商用户ID=${prizeSupplierUserId}`);
                
                // 统一使用decimal格式
                const profitAmount = parseFloat(config.amount).toFixed(2);
                
                // 百分比只是用来显示的，设为0即可
                const percentage = "0.00";
                await connection.execute(`
                    INSERT INTO fa_profit_record 
                    (order_id, device_id, user_id, total_amount, profit_user_id, profit_role, profit_percentage, profit_amount, status, createtime)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    orderId,
                    deviceId, 
                    lotteryUserId,
                    orderAmount,
                    prizeSupplierUserId, // 使用中奖奖品的supplier_user_id
                    config.role_name, // 只显示"奖品供应商"
                    percentage,
                    profitAmount,
                    1,
                    currentTime
                ]);
                
                // 更新供应商余额
                await connection.execute(`
                    UPDATE fa_admin SET balance = balance + ? WHERE id = ?
                `, [profitAmount, prizeSupplierUserId]);
                
                profitRecords.push({
                    role: config.role_name,
                    user_id: prizeSupplierUserId,
                    amount: profitAmount,
                    percentage: percentage
                });
                
                console.log(`💰 奖品供应商分润成功: 用户${prizeSupplierUserId} 分得${profitAmount} (${percentage}%), 余额已更新`);
                continue;
            }
            
            // 其他角色的正常分润逻辑
            if (profitUserId && profitUserId > 0) {
                // 统一使用decimal格式
                const profitAmount = parseFloat(config.amount).toFixed(2);
                
                // 百分比只是用来显示的，设为0即可
                const percentage = "0.00";
                await connection.execute(`
                    INSERT INTO fa_profit_record 
                    (order_id, device_id, user_id, total_amount, profit_user_id, profit_role, profit_percentage, profit_amount, status, createtime)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    orderId,
                    deviceId, 
                    lotteryUserId, // 抽奖用户ID
                    orderAmount, // 统一decimal格式
                    profitUserId, // 分润用户ID
                    config.role_name,
                    percentage, // 百分比只是显示用，设为0
                    profitAmount, // 统一decimal格式
                    1, // 已结算
                    currentTime
                ]);
                
                // 更新用户余额（统一decimal格式）
                await connection.execute(`
                    UPDATE fa_admin SET balance = balance + ? WHERE id = ?
                `, [profitAmount, profitUserId]);
                
                profitRecords.push({
                    role: config.role_name,
                    user_id: profitUserId,
                    amount: profitAmount,
                    percentage: percentage
                });
                
                console.log(`💰 分润记录创建成功: ${config.role_name} 用户${profitUserId} 分得${profitAmount} (${percentage}%), 余额已更新`);
            }
        }
        
        // 计算平台留存并分给admin账户
        const totalDistributed = profitRecords.reduce((sum, record) => sum + parseFloat(record.amount), 0);
        const platformProfit = (orderAmount - totalDistributed).toFixed(2);
        
        if (parseFloat(platformProfit) > 0) {
            // 百分比只是用来显示的，设为0即可
            const platformPercentage = "0.00";
            await connection.execute(`
                INSERT INTO fa_profit_record 
                (order_id, device_id, user_id, total_amount, profit_user_id, profit_role, profit_percentage, profit_amount, status, createtime)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                orderId,
                deviceId, 
                lotteryUserId, // 抽奖用户ID
                orderAmount, // 统一decimal格式
                1, // admin用户ID
                '平台留存',
                platformPercentage,
                platformProfit, // 统一decimal格式
                1, // 已结算
                currentTime
            ]);
            
            // 更新admin余额（统一decimal格式）
            await connection.execute(`
                UPDATE fa_admin SET balance = balance + ? WHERE id = 1
            `, [platformProfit]);
            
            profitRecords.push({
                role: '平台留存',
                user_id: 1,
                amount: platformProfit,
                percentage: platformPercentage
            });
            
            console.log(`🏦 平台留存创建成功: admin用户 分得${platformProfit} (${platformPercentage}%), 余额已更新`);
        }
        
        // 提交事务
        await connection.commit();
        console.log(`✅ 分润处理完成: 配置=${config_name}, 总金额=${orderAmount}, 已分配=${totalDistributed.toFixed(2)}, 平台留存=${platformProfit}`);
        return profitRecords;
        
    } catch (error) {
        // 回滚事务
        await connection.rollback();
        console.error('❌ 创建分润记录失败:', error);
        return [];
    } finally {
        connection.release();
    }
}

// 测试数据库连接
async function testDBConnection() {
    try {
        const connection = await pool.getConnection();
        await connection.execute('SELECT 1');
        connection.release();
        console.log('✅ 数据库连接测试成功');
    } catch (error) {
        console.error('❌ 数据库连接失败:', error);
    }
}

// 验证设备是否存在的函数
async function verifyDevice(deviceId) {
    try {
        const response = await axios.post(`${config.apiBaseUrl}/device/info`, {
            device_id: deviceId
        }, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        return response.data.code === 1;
    } catch (error) {
        console.log(`设备验证失败: ${deviceId}`, error.message);
        return false;
    }
}

// WebSocket连接处理
io.on('connection', (socket) => {
    console.log(`新连接: ${socket.id}`);

    // 设备注册
    socket.on('device_register', async (data) => {
        const { device_id, device_type = 'android' } = data;
        
        if (!device_id) {
            socket.emit('error', { message: '设备ID不能为空' });
            return;
        }

        // 验证设备是否存在
        const isValidDevice = await verifyDevice(device_id);
        if (!isValidDevice) {
            socket.emit('device_register_response', {
                success: false,
                message: '设备未注册或不存在'
            });
            return;
        }

        // 注册设备
        devices.set(socket.id, {
            device_id,
            device_type,
            socket_id: socket.id,
            connected_at: new Date(),
            last_heartbeat: new Date()
        });

        // 加入设备房间
        const roomName = `device_${device_id}`;
        socket.join(roomName);
        deviceRooms.set(device_id, roomName);

        console.log(`设备注册成功: ${device_id} (${socket.id})`);
        
        socket.emit('device_register_response', {
            success: true,
            message: '设备注册成功',
            device_id,
            room: roomName
        });
    });

    // 用户加入设备房间
    socket.on('user_join', async (data) => {
        const { device_id, user_info } = data;
        
        if (!device_id) {
            socket.emit('error', { message: '设备ID不能为空' });
            return;
        }

        // 验证设备是否在线
        const roomName = deviceRooms.get(device_id);
        if (!roomName) {
            socket.emit('user_join_response', {
                success: false,
                message: '设备不在线或不存在'
            });
            return;
        }

        // 验证设备是否存在
        const isValidDevice = await verifyDevice(device_id);
        if (!isValidDevice) {
            socket.emit('user_join_response', {
                success: false,
                message: '设备未注册或不存在'
            });
            return;
        }

        // 注册用户
        users.set(socket.id, {
            device_id,
            user_info: user_info || {},
            socket_id: socket.id,
            joined_at: new Date()
        });

        // 加入设备房间
        socket.join(roomName);

        console.log(`用户加入设备房间: ${device_id} (${socket.id})`);

        socket.emit('user_join_response', {
            success: true,
            message: '成功连接到设备',
            device_id,
            room: roomName
        });

        // 通知设备有用户加入
        socket.to(roomName).emit('user_connected', {
            user_id: socket.id,
            user_info: user_info || {},
            message: '有用户加入游戏'
        });
    });

    // 用户发起抽奖
    socket.on('start_lottery', async (data) => {
        console.log('收到抽奖请求:', data);
        
        const { device_id, user_id, openid, game_type = 'lottery', config_id } = data;
        
        // 如果没有指定设备ID，返回错误
        if (!device_id) {
            socket.emit('error', { message: '缺少设备ID' });
            return;
        }
        
        // 验证config_id（如果提供）
        if (config_id) {
            const configResult = await getProfitConfigById(device_id, config_id);
            if (!configResult) {
                socket.emit('error', { 
                    message: `分润配置ID=${config_id}无效或不属于该设备`,
                    code: 'INVALID_CONFIG_ID'
                });
                return;
            }
            console.log(`✅ 验证分润配置成功: ID=${config_id}, 名称=${configResult.config_name}, 金额=${configResult.lottery_amount}元`);
        }
        
        // 自动将用户加入到设备房间（简化流程）
        const roomName = `device_${device_id}`;
        socket.join(roomName);
        
        console.log(`用户 ${user_id} (openid: ${openid}) 自动加入设备 ${device_id}${config_id ? ', config_id=' + config_id : ''}`);
        
        // 查找已支付的订单（必须存在）
        const connection = await pool.getConnection();
        let existingOrder = null;
        try {
            const [rows] = await connection.execute(
                `SELECT id, order_amount FROM fa_order 
                 WHERE openid = ? AND order_status = 1 AND prize_id = 0 
                 ORDER BY createtime DESC LIMIT 1`,
                [openid || '']
            );
            
            if (rows.length > 0) {
                existingOrder = rows[0];
                console.log(`🔍 找到已支付订单: ID=${existingOrder.id}, 金额=${existingOrder.order_amount}元`);
            }
        } catch (error) {
            console.error('❌ 查询已支付订单失败:', error);
        } finally {
            connection.release();
        }
        
        // 如果没有找到已支付订单，返回错误
        if (!existingOrder) {
            socket.emit('error', { 
                message: '未找到已支付订单，请先支付再开始游戏',
                code: 'NO_PAID_ORDER'
            });
            console.warn(`⚠️ 用户${user_id}未找到已支付订单，openid=${openid}`);
            return;
        }
        
        // 使用已支付订单
        const saveResult = { success: true, order_id: existingOrder.id };
        const orderAmount = parseFloat(existingOrder.order_amount);
        console.log(`🎮 使用已支付订单: 订单ID=${existingOrder.id}, 金额=${orderAmount}元`);
        
        // 抽奖时不立即分润，等中奖结果确定后再分润
        console.log(`⏰ 延迟分润: 等待抽奖结果确定后再进行分润处理`);

        // 更新用户信息，包含订单ID、openid和config_id
        users.set(socket.id, {
            device_id: device_id,
            user_id: user_id || 'user_' + Date.now(),
            openid: openid || '',
            game_type: game_type,
            config_id: config_id || null, // 新增：保存分润配置ID
            order_id: saveResult.order_id,
            order_amount: orderAmount, // 保存订单金额，用于后续分润
            joined_at: new Date()
        });
        
        const { lottery_type = 1, user_name, user_phone } = data;
        
        // 获取用户信息
        const user = users.get(socket.id);
        let targetRoomName = deviceRooms.get(device_id);
        
        // 如果设备不在线，仍然发送指令（可能是离线处理）
        if (!targetRoomName) {
            targetRoomName = roomName; // 使用当前房间名
            console.log(`设备 ${device_id} 离线，尝试发送指令到房间 ${targetRoomName}`);
        }

        const lotteryData = {
            user_id: user.user_id,
            device_id: device_id,
            lottery_type,
            user_name,
            user_phone,
            order_id: saveResult.order_id,
            order_amount: orderAmount,
            config_id: config_id, // 新增：传递分润配置ID给安卓端
            timestamp: new Date().toISOString()
        };

        console.log(`用户发起抽奖: ${device_id}`, lotteryData);

        // 发送抽奖指令给设备
        socket.to(targetRoomName).emit('lottery_command', lotteryData);
        
        // 同时发送给所有连接到该设备的客户端
        io.to(roomName).emit('game_started', {
            device_id: device_id,
            user_id: user.user_id,
            order_id: saveResult.order_id,
            order_amount: orderAmount,
            message: '抽奖已开始，使用已支付订单，等待抽奖结果确定后分润'
        });

        // 确认用户抽奖请求已发送
        socket.emit('lottery_sent', {
            success: true,
            message: '抽奖指令已发送到设备，使用已支付订单，等待抽奖结果',
            order_id: saveResult.order_id,
            order_amount: orderAmount,
            data: lotteryData
        });
    });

    // 设备返回抽奖结果
    socket.on('lottery_result', async (data) => {
        const device = devices.get(socket.id);
        if (!device) {
            socket.emit('error', { message: '设备未注册' });
            return;
        }

        const { user_id, result, prize_info, lottery_record_id } = data;
        const roomName = deviceRooms.get(device.device_id);

        console.log(`设备返回抽奖结果: ${device.device_id}`, data);

        // 查找对应的用户信息，获取订单ID、订单金额和config_id
        let targetOrderId = null;
        let orderAmount = null;
        let userInfo = null;
        let configId = null;
        for (const [socketId, info] of users.entries()) {
            if (info.user_id === user_id && info.device_id === device.device_id) {
                targetOrderId = info.order_id;
                orderAmount = info.order_amount;
                userInfo = info;
                configId = info.config_id; // 获取config_id
                break;
            }
        }

        // 现在进行分润处理（无论中奖还是未中奖都分润，但奖品供应商只有中奖时才分润给对应供应商）
        let profitRecords = [];
        if (targetOrderId && orderAmount) {
            console.log(`💰 开始处理抽奖结果分润: 订单ID=${targetOrderId}, 金额=${orderAmount}元${configId ? ', config_id=' + configId : ''}`);
            profitRecords = await createProfitRecords(targetOrderId, device.device_id, user_id, orderAmount, prize_info, configId);
        }

        // 如果中奖且找到了订单ID，更新订单奖品信息
        if (result === 'win' && prize_info && targetOrderId) {
            const updateResult = await updateOrderPrize(targetOrderId, prize_info);
            if (updateResult.success) {
                data.order_id = targetOrderId;
                console.log(`🎁 订单奖品更新成功: 用户=${user_id}, 奖品=${prize_info.name}, 订单ID=${targetOrderId}`);
            }
        } else if (result === 'win' && prize_info) {
            // 如果没找到订单ID，记录警告
            console.warn(`⚠️ 中奖但未找到对应订单: 用户=${user_id}, 设备=${device.device_id}`);
        }

        // 发送结果给指定用户
        if (user_id) {
            io.to(user_id).emit('lottery_result', {
                success: true,
                result,
                prize_info,
                lottery_record_id,
                device_id: device.device_id,
                order_id: data.order_id, // 包含订单ID
                profit_info: profitRecords, // 包含分润信息
                profit_summary: profitRecords.map(r => `${r.role}: ${r.amount}元`),
                timestamp: new Date().toISOString()
            });
        }

        // 广播给房间内所有用户（用于大屏显示）
        socket.to(roomName).emit('lottery_broadcast', {
            result,
            prize_info,
            device_id: device.device_id,
            profit_info: profitRecords, // 包含分润信息
            timestamp: new Date().toISOString()
        });
    });

    // 心跳检测
    socket.on('heartbeat', () => {
        const device = devices.get(socket.id);
        if (device) {
            device.last_heartbeat = new Date();
        }
        socket.emit('heartbeat_response', { timestamp: new Date().toISOString() });
    });

    // 获取设备状态
    socket.on('get_device_status', () => {
        const device = devices.get(socket.id);
        if (device) {
            const roomName = deviceRooms.get(device.device_id);
            const roomUsers = Array.from(users.values()).filter(u => u.device_id === device.device_id);
            
            socket.emit('device_status', {
                device_info: device,
                room: roomName,
                connected_users: roomUsers.length,
                users: roomUsers.map(u => ({ user_id: u.socket_id, user_info: u.user_info }))
            });
        }
    });

    // 连接断开处理
    socket.on('disconnect', () => {
        console.log(`连接断开: ${socket.id}`);

        // 清理设备信息
        const device = devices.get(socket.id);
        if (device) {
            const roomName = deviceRooms.get(device.device_id);
            if (roomName) {
                // 通知房间内的用户设备已断开
                socket.to(roomName).emit('device_disconnected', {
                    device_id: device.device_id,
                    message: '设备已断开连接'
                });
                deviceRooms.delete(device.device_id);
            }
            devices.delete(socket.id);
            console.log(`设备断开: ${device.device_id}`);
        }

        // 清理用户信息
        const user = users.get(socket.id);
        if (user) {
            const roomName = deviceRooms.get(user.device_id);
            if (roomName) {
                // 通知设备用户已断开
                socket.to(roomName).emit('user_disconnected', {
                    user_id: socket.id,
                    device_id: user.device_id,
                    message: '用户已断开连接'
                });
            }
            users.delete(socket.id);
            console.log(`用户断开: ${user.device_id}`);
        }
    });
});

// HTTP API接口
app.get('/status', (req, res) => {
    res.json({
        success: true,
        server: 'TV Demo WebSocket Server',
        timestamp: new Date().toISOString(),
        connections: {
            total: devices.size + users.size,
            devices: devices.size,
            users: users.size
        },
        rooms: Array.from(deviceRooms.keys())
    });
});

app.get('/devices', (req, res) => {
    const deviceList = Array.from(devices.values()).map(device => ({
        device_id: device.device_id,
        device_type: device.device_type,
        connected_at: device.connected_at,
        last_heartbeat: device.last_heartbeat
    }));
    
    res.json({
        success: true,
        devices: deviceList,
        total: deviceList.length
    });
});

// 查询订单接口
app.get('/orders', async (req, res) => {
    try {
        const { device_id, user_id, limit = 50 } = req.query;
        
        let sql = 'SELECT * FROM fa_order WHERE 1=1';
        const params = [];
        
        if (device_id) {
            sql += ' AND device_id = ?';
            params.push(device_id);
        }
        
        if (user_id) {
            sql += ' AND pay_user = ?';
            params.push(user_id);
        }
        
        sql += ' ORDER BY createtime DESC LIMIT ?';
        params.push(parseInt(limit));
        
        const connection = await pool.getConnection();
        const [rows] = await connection.execute(sql, params);
        connection.release();
        
        res.json({
            success: true,
            orders: rows,
            total: rows.length
        });
        
    } catch (error) {
        console.error('查询订单失败:', error);
        res.status(500).json({
            success: false,
            message: '查询订单失败',
            error: error.message
        });
    }
});

// 查询单个订单接口
app.get('/orders/:id', async (req, res) => {
    try {
        const orderId = req.params.id;
        
        const connection = await pool.getConnection();
        const [rows] = await connection.execute(
            'SELECT * FROM fa_order WHERE id = ?',
            [orderId]
        );
        connection.release();
        
        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: '订单不存在'
            });
        }
        
        res.json({
            success: true,
            order: rows[0]
        });
        
    } catch (error) {
        console.error('查询订单详情失败:', error);
        res.status(500).json({
            success: false,
            message: '查询订单详情失败',
            error: error.message
        });
    }
});

// 启动服务器
server.listen(config.port, async () => {
    console.log(`🚀 TV Demo WebSocket服务器启动成功!`);
    console.log(`📡 端口: ${config.port}`);
    console.log(`🌐 状态接口: http://localhost:${config.port}/status`);
    console.log(`📱 设备列表: http://localhost:${config.port}/devices`);
    console.log(`⏰ 启动时间: ${new Date().toLocaleString()}`);
    
    // 测试数据库连接
    await testDBConnection();
});

// 定期清理心跳超时的连接
setInterval(() => {
    const now = new Date();
    const timeout = 5 * 60 * 1000; // 5分钟超时

    devices.forEach((device, socketId) => {
        if (now - device.last_heartbeat > timeout) {
            console.log(`设备心跳超时，断开连接: ${device.device_id}`);
            const socket = io.sockets.sockets.get(socketId);
            if (socket) {
                socket.disconnect();
            }
        }
    });
}, 60000); // 每分钟检查一次
