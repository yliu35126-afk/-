const { pool } = require('./database');

// 分润服务模块

async function getDeviceRoleUsers(deviceId, profitConfig) {
    const connection = await pool.getConnection();
    try {
        // 首先获取设备表中的角色字段
        const [deviceRows] = await connection.execute(`
            SELECT d.sheng_daili_id, d.shi_daili_id, d.quxian_daili_id, 
                   d.shebei_goumaizhe_id, d.shebei_pushezhe_id, d.shiti_shangjia_id, d.jiangpin_gongyingshang_ids
            FROM fa_device d WHERE d.device_id = ?
        `, [deviceId]);
        
        if (deviceRows.length === 0) return {};
        
        const device = deviceRows[0];
        
        // 从数据库获取角色配置，建立动态映射关系
        const [roleRows] = await connection.execute(`
            SELECT id, name FROM fa_auth_group WHERE status = 'normal' ORDER BY id
        `);
        
        // 创建角色名称到设备字段的映射（基于角色名称匹配）
        const roleFieldMapping = {};
        roleRows.forEach(role => {
            switch(role.name) {
                case '省代理':
                    roleFieldMapping[role.id] = device.sheng_daili_id;
                    break;
                case '市代理':
                    roleFieldMapping[role.id] = device.shi_daili_id;
                    break;
                case '区县代理':
                    roleFieldMapping[role.id] = device.quxian_daili_id;
                    break;
                case '设备购买者':
                    roleFieldMapping[role.id] = device.shebei_goumaizhe_id;
                    break;
                case '设备铺设者':
                    roleFieldMapping[role.id] = device.shebei_pushezhe_id;
                    break;
                case '实体商家':
                    roleFieldMapping[role.id] = device.shiti_shangjia_id;
                    break;
                case '奖品供应商':
                    roleFieldMapping[role.id] = device.jiangpin_gongyingshang_ids;
                    break;
                default:
                    // 其他角色（超级管理组、游戏、运营团队、管理员等）没有对应的设备字段
                    roleFieldMapping[role.id] = null;
                    break;
            }
        });
        
        console.log(`🗂️ 动态角色映射关系:`, roleFieldMapping);
        
        // 根据分润配置中的角色构建返回结果
        const result = {};
        for (const [configKey, config] of Object.entries(profitConfig)) {
            const roleId = config.role_id;
            const deviceUserId = roleFieldMapping[roleId];
            
            // 只有当设备表中有绑定用户且用户ID > 0时，才分润给该角色
            if (deviceUserId && deviceUserId > 0) {
                result[configKey] = deviceUserId;
            }
            // 如果设备没有绑定该角色用户，就不加入result，不进行分润
        }
        
        console.log(`🔍 设备${deviceId}角色用户映射 (共${Object.keys(result).length}个角色):`, result);
        return result;
        
    } catch (error) {
        console.error('❌ 获取设备角色用户失败:', error);
        return {};
    } finally {
        connection.release();
    }
}

// 获取设备指定金额的分润配置（保留兼容性）
async function getProfitConfigByDeviceAndAmount(deviceId, lotteryAmount) {
    const connection = await pool.getConnection();
    try {
        // 1. 获取设备绑定的分润配置IDs
        const [deviceRows] = await connection.execute(
            'SELECT profit_config_ids FROM fa_device WHERE device_id = ?',
            [deviceId]
        );
        
        if (deviceRows.length === 0 || !deviceRows[0].profit_config_ids) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置`);
            return null;
        }
        
        const profitConfigIds = JSON.parse(deviceRows[0].profit_config_ids);
        if (!Array.isArray(profitConfigIds) || profitConfigIds.length === 0) {
            console.warn(`⚠️ 设备${deviceId}分润配置ID数组为空`);
            return null;
        }
        
        // 2. 根据抽奖金额查找对应的分润配置
        // 注意：统一使用decimal格式匹配
        const [configRows] = await connection.execute(
            'SELECT id, config_name, lottery_amount, config_data FROM fa_profit_config WHERE id IN (' + 
            profitConfigIds.map(() => '?').join(',') + ') AND lottery_amount = ? AND status = 1',
            [...profitConfigIds, lotteryAmount]
        );
        
        if (configRows.length === 0) {
            console.warn(`⚠️ 设备${deviceId}未找到金额为${lotteryAmount}的分润配置`);
            return null;
        }
        
        const config = configRows[0];
        const configData = JSON.parse(config.config_data);
        
        // 3. 转换配置数据为分润角色映射
        const profitConfig = {};
        
        // 遍历config_data中的角色配置（排除prizes部分）
        Object.keys(configData).forEach(key => {
            if (key !== 'prizes' && configData[key].role_name && configData[key].amount !== undefined) {
                const roleData = configData[key];
                
                // 直接使用配置项的key作为角色标识，同时保存role_id
                if (parseFloat(roleData.amount) > 0) {
                    const roleAmount = parseFloat(roleData.amount);
                    
                    profitConfig[key] = {
                        role_id: roleData.role_id,
                        role_name: roleData.role_name,
                        amount: roleAmount // 统一使用decimal格式，不除以100
                    };
                }
            }
        });
        
        console.log(`✅ 获取设备${deviceId}金额${lotteryAmount}的分润配置成功:`, profitConfig);
        return {
            config_id: config.id,
            config_name: config.config_name,
            lottery_amount: parseFloat(config.lottery_amount),
            profit_config: profitConfig
        };
        
    } catch (error) {
        console.error(`❌ 获取设备${deviceId}分润配置失败:`, error);
        return null;
    } finally {
        connection.release();
    }
}

// 根据config_id获取设备分润配置（新增）
async function getProfitConfigById(deviceId, configId) {
    const connection = await pool.getConnection();
    try {
        // 1. 获取设备绑定的分润配置IDs
        const [deviceRows] = await connection.execute(
            'SELECT profit_config_ids FROM fa_device WHERE device_id = ?',
            [deviceId]
        );
        
        if (deviceRows.length === 0 || !deviceRows[0].profit_config_ids) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置`);
            return null;
        }
        
        const profitConfigIds = JSON.parse(deviceRows[0].profit_config_ids);
        if (!Array.isArray(profitConfigIds) || profitConfigIds.length === 0) {
            console.warn(`⚠️ 设备${deviceId}分润配置ID数组为空`);
            return null;
        }
        
        console.log(`🔍 设备${deviceId}绑定的分润配置IDs:`, profitConfigIds);
        console.log(`🎯 验证config_id=${configId} (类型: ${typeof configId})`);
        
        // 2. 验证config_id是否在设备绑定的配置列表中
        // 处理字符串和数字的匹配问题
        const configIdNum = parseInt(configId);
        const configIdStr = String(configId);
        const isIncluded = profitConfigIds.includes(configIdNum) || profitConfigIds.includes(configIdStr);
        
        if (!isIncluded) {
            console.warn(`⚠️ 设备${deviceId}未绑定分润配置ID=${configId}, 绑定的配置: [${profitConfigIds.join(', ')}]`);
            return null;
        }
        
        // 3. 根据config_id直接查找分润配置
        const [configRows] = await connection.execute(
            'SELECT id, config_name, lottery_amount, config_data FROM fa_profit_config WHERE id = ? AND status = 1',
            [configId]
        );
        
        if (configRows.length === 0) {
            console.warn(`⚠️ 分润配置ID=${configId}不存在或已禁用`);
            return null;
        }
        
        const config = configRows[0];
        const configData = JSON.parse(config.config_data);
        
        // 4. 转换配置数据为分润角色映射
        const profitConfig = {};
        
        // 遍历config_data中的角色配置（排除prizes部分）
        Object.keys(configData).forEach(key => {
            if (key !== 'prizes' && configData[key].role_name && configData[key].amount !== undefined) {
                const roleData = configData[key];
                
                // 直接使用配置项的key作为角色标识，同时保存role_id
                if (parseFloat(roleData.amount) > 0) {
                    const roleAmount = parseFloat(roleData.amount);
                    
                    profitConfig[key] = {
                        role_id: roleData.role_id,
                        role_name: roleData.role_name,
                        amount: roleAmount // 统一使用decimal格式，不除以100
                    };
                }
            }
        });
        
        console.log(`✅ 获取设备${deviceId}分润配置ID=${configId}成功:`, profitConfig);
        return {
            config_id: config.id,
            config_name: config.config_name,
            lottery_amount: parseFloat(config.lottery_amount),
            profit_config: profitConfig
        };
        
    } catch (error) {
        console.error(`❌ 获取设备${deviceId}分润配置ID=${configId}失败:`, error);
        return null;
    } finally {
        connection.release();
    }
}

module.exports = {
    getDeviceRoleUsers,
    getProfitConfigByDeviceAndAmount,
    getProfitConfigById
};