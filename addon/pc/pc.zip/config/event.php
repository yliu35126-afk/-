<?php
// 事件定义文件
return [
    'bind' => [

    ],

    'listen' => [

    ],

    'subscribe' => [
    ],
];
